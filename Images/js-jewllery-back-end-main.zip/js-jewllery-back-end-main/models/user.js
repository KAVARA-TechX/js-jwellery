const mongoose = require('mongoose');
// const {objectId} = mongoose.Schema;

const userSchema = new mongoose.Schema(
    {
        
        salutation:String,
        name:String,
        mobile:Number,
        pinCode: Number,
        address:String,
        dateOfBirth: Date,
        anniversery: Date,
        occupation: String,
        spouseBirthday: Date,
        email:{
            type:String,
            required:true,
            index:true,
        },
        role:{
            type:String,
            default:"subscriber",
        },
        // wishlist:[{ type: ObjectId, ref: "Product" }],

    },
    {timestamps:true}
);

module.exports = mongoose.model("User",userSchema);