const express = require('express');

const router = express.Router();

//middlewares :- for checking token 
const {authCheck,adminCheck} = require("../middleware/auth");

//controller :- for express front-back end handling i.e req&res
const {create} = require('../controllers/product');

//routes
//to create a product
router.post("/product",authCheck,adminCheck,create);
//to get all porducts from the database

module.exports = router;
